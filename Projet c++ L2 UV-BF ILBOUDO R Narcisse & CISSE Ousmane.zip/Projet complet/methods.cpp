// DEclaration et implementation des differents fonctions :

#include "declare.h"
int somme(int a, int b){
return a+b;
}
