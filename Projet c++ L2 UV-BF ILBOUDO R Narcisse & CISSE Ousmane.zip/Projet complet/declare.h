

int somme( int a, int b);
